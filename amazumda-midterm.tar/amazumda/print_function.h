#ifndef _PRINT_FUNCTION_H_
#define _PRINT_FUNCTION_H_
#include "ls.h"

void
print_function(node,struct opts_holder,int *);

#endif
